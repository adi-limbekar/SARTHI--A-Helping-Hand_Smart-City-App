package com.fyp.saarthi;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.fyp.saarthi.com.fyp.model.User;
import com.fyp.saarthi.util.HttpManager;
import com.google.gson.Gson;

import static com.fyp.saarthi.util.Utility.checkEmail;
import static com.fyp.saarthi.util.Utility.checkPassword;
import static com.fyp.saarthi.util.Utility.checkPhoneNumber;

public class ActivityRegistration extends AppCompatActivity {

    TextView tvRegError;
    EditText etName;
    EditText etPhoneNumber;
    EditText etEmail;
    EditText etPassword;
    RadioGroup rgGender;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        tvRegError = findViewById(R.id.tvRegError);
        etName = findViewById(R.id.etName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        rgGender = findViewById(R.id.rgGender);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Name*/
                int flag = 0;
                System.out.println("Button Clicked");
                String name = etName.getText().toString().trim();
                System.out.println("name - " + name);
                if (TextUtils.isEmpty(name)) {
                    etName.setError("Enter the name");
                    etName.requestFocus();
                    return;
                }
                /*Phone_number*/
                String PhoneNumber = etPhoneNumber.getText().toString().trim();
                if (checkPhoneNumber(PhoneNumber) == 0 || TextUtils.isEmpty(PhoneNumber)) {
                    etPhoneNumber.setError("Enter valid PhoneNumber");
                    etPhoneNumber.requestFocus();
                    return;
                } else {
                    System.out.println("Phone_Number - " + PhoneNumber);
                }


                /*E=mail*/
                String Email = etEmail.getText().toString().trim();

                if (checkEmail(Email) == 0 || TextUtils.isEmpty(Email)) {
                    etEmail.setError("Enter valid Email");
                    etEmail.requestFocus();
                    return;
                } else {
                    System.out.println("Email - " + Email);
                }
                /*Password*/
                String Password = etPassword.getText().toString().trim();

                if (checkPassword(Password) == 0 || TextUtils.isEmpty(Password)) {
                    etPassword.setError("Enter valid Password");
                    etPassword.requestFocus();
                    return;
                } else {
                    System.out.println("Password - " + Password);
                }

                String RadioButtonValue = ((RadioButton) findViewById(rgGender.getCheckedRadioButtonId())).getText().toString().trim();
                System.out.println("Gender - " + RadioButtonValue);

                /*checkbox courses*/


                User user = new User();
                user.setEmailId(Email);
                user.setGender(RadioButtonValue);
                //user.setCourses();
                user.setMobileNumber(PhoneNumber);
                user.setName(name);
                user.setPassword(Password);

                Gson gson = new Gson();
                String userJson = gson.toJson(user);
                new RegistrationTask().execute(userJson);

            }
        });
    }


    class RegistrationTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String userJson = strings[0];
            HttpManager httpManager = new HttpManager();
            String res = httpManager.postData("http://192.168.43.2:8081/sample/webapi/UserService/registerUser", userJson);
            return res;
        }

        @Override
        protected void onPostExecute(String result) {
            System.out.println("result - " + result);
            if (result.equals("1")) {
                Intent intent = new Intent(ActivityRegistration.this, ActivityHome.class);
                startActivity(intent);
                finish();
            } else {
                tvRegError.setVisibility(View.VISIBLE);
                Toast.makeText(getApplication(), "Registration failed", Toast.LENGTH_LONG).show();
            }
        }
    }

    }

