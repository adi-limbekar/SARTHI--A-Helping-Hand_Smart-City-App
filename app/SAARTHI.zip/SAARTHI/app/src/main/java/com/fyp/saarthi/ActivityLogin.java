package com.fyp.saarthi;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.fyp.saarthi.com.fyp.model.User;
import com.fyp.saarthi.util.HttpManager;
import com.fyp.saarthi.util.SessionManager;
import com.google.gson.Gson;

import org.json.JSONArray;

public class ActivityLogin extends AppCompatActivity {

    public JSONArray arr = null;
    EditText etRegPhoneNo;

    EditText etRegPassword;
    Button btnLogin;
    String RegNumber;
    String RegPassword;
    TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etRegPhoneNo = findViewById(R.id.etRegPhoneNo);
        etRegPassword = findViewById(R.id.etRegPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvLogin = findViewById(R.id.tvLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                RegNumber = etRegPhoneNo.getText().toString().trim();
                if(TextUtils.isEmpty(RegNumber)){
                    etRegPhoneNo.setError("Enter the Registered_number");
                    etRegPhoneNo.requestFocus();
                    return;
                }
                else{
                    System.out.println("Registered_number - "+RegNumber);
                }

                RegPassword = etRegPassword.getText().toString().trim();
                if(TextUtils.isEmpty(RegPassword)){
                    etRegPassword.setError("Enter the Registered_Password");
                    etRegPassword.requestFocus();
                    return;
                }
                else{
                    System.out.println("Registered_password - "+RegPassword);
                }

                User user = new User();
                user.setMobileNumber(RegNumber);
                user.setPassword(RegPassword);

                Gson gson = new Gson();
                String userJson = gson.toJson(user);
                new LoginTask().execute(userJson);
            }
        });

        tvLogin = findViewById(R.id.tvLogin);
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ActivityLogin.this, ActivityRegistration.class);
                startActivity(i);
            }
        });
    }

    class LoginTask extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... strings) {
            String userJson = strings[0];
            HttpManager httpManager = new HttpManager();
            String res = httpManager.postData(getString(R.string.baseUrl)+"UserService/getUserDetails",userJson);
            return res;
        }
        @Override
        protected void onPostExecute(String result) {
            System.out.println("result - "+result);

            if(result!=null) {
                Gson gson = new Gson();
                User user = gson.fromJson(result, User.class);
                SessionManager sessionManager = new SessionManager(getApplicationContext());
                sessionManager.putString("loggedInUser", result);

                Toast.makeText(getApplication(), "Login Successful", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ActivityLogin.this, ActivityHome.class);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(getApplication(), "Login Failed! Please Try Again", Toast.LENGTH_LONG).show();
            }



        }

    }
}
